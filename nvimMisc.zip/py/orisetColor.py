vim.api.set_hl(0, "Normal", {'fg':"Yellow", 'bg':"none"}) #Cyan yellow Orange Purple
vim.api.set_hl(0, "Cursor", {'fg':"yellow", 'bg':"none"})
vim.api.set_hl(0, "CurSearch", {'fg':"red", 'bg':"cyan", 'bold':True})
vim.api.set_hl(0, "CursorLine", {'fg':"none", 'bg':"none"})
vim.api.set_hl(0, "VertSplit", {'fg':"red", 'bg':"none"})
vim.api.set_hl(0, "TabLineSel", {'fg':"yellow", 'bg':"none", 'bold':True})
vim.api.set_hl(0, "TabLine", {'fg':"red", 'bg':"none"})
vim.api.set_hl(0, "TabLineFill", {'fg':"green", 'bg':"none"})
vim.api.set_hl(0, "Title", {'fg':"orange", 'bg':"none"})
vim.api.set_hl(0, "Visual", {'fg':"yellow", 'bg':"Magenta", 'bold':True})
vim.api.set_hl(0, "Search", {'fg':"red", 'bg':"none", 'bold':True, 'italic':True})
vim.api.set_hl(0, "MatchParen", {'fg':"red", 'bg':"none"})
vim.api.set_hl(0, "ModeMsg", {'fg':"cyan", 'bg':"none", 'bold':True})
vim.api.set_hl(0, "WarningMsg", {'fg':"Red", 'bg':"none"})
vim.api.set_hl(0, "StatusLine", {'fg':"Yellow", 'bg':"DarkBlue", 'bold':True})
vim.api.set_hl(0, "pythonString", {'fg':"Cyan", 'bg':"None"})
vim.api.set_hl(0, "pythonComment", {'fg':"White", 'bg':"None"})
vim.api.set_hl(0, "pythonStatement", {'fg':"Violet", 'bg':"None"})
vim.api.set_hl(0, "pythonBuiltin", {'fg':"Yellow", 'bg':"None"})
#Magenta={ 'gui':'#8b008b', 'cterm':90 } #darkmagenta

#fg (or foreground), bg (or background), sp (or special), blend, bold, standout, underline, undercurl, underdouble, underdotted, underdashed, strikethrough, italic, reverse, nocombine, link
#vim.command('exec "hi! TabLineSel gui=bold"')
#vim.command('exec "hi! StatusLine gui=bold"')
#vim.command('exec "hi! TabLineSel gui=bold"')
#vim.api.set_hl(0, "pythonStatement", {'fg':"cyan", 'bg':"Red"})
#hiSET(, base5, base2)
vim.api.set_option('termguicolors', True)
'''
hi guifg=cyan
hi pythonBuiltin guifg=Yellow
hi pythonString guifg=Yellow
hi pythonStatement guifg=Yellow
Red LightRed DarkRed
Green LightGreen DarkGreen SeaGreen
Blue LightBlue DarkBlue SlateBlue
Cyan LightCyan DarkCyan
Magenta LightMagenta DarkMagenta
Yellow LightYellow Brown DarkYellow
Gray LightGray DarkGray
Black White
Orange Purple Violet

hi Normal gui=bold guifg=magnenta
'Normal', 'Cursor', 'CurSearch', 'CursorLine', 'CursorColumn', 'LineNr', 'CursorLineNr', 'SignColumn', 'ColorColumn', 'Conceal', 'Todo', 'Comment', 'String', 'Number', 'Statement', 'Special', 'Identifier', 'Constant', 'VertSplit', 'StatusLine', 'WildMenu', 'StatusLineNC', 'ErrorMsg', 'Error', 'ModeMsg', 'WarningMsg', 'TabLineSel', 'TabLine', 'TabLineFill', 'Title', 'Visual', 'Search', 'MatchParen', 'IncSearch', 'reverse', 'Pmenu', 'PmenuSel', 'PmenuSbar', 'PmenuThumb', 'CtrlPNoEntries', 'CtrlPMatch', 'CtrlPPrtBase', 'CtrlPPrtText', 'CtrlPPtrCursor', 'pythonStatement'
colors = {}

base0 = { 'gui': '#0c1014', 'cterm':16 }
base1 = { 'gui': '#11151c', 'cterm':233 }
base2 = { 'gui': '#091f2e', 'cterm':17 }
base3 = { 'gui': '#0a3749', 'cterm':18 }
base4 = { 'gui': '#1e6479', 'cterm':31 }
base5 = { 'gui': '#599cab', 'cterm':81 }
base6 = { 'gui': '#99d1ce', 'cterm':122 }
base7 = { 'gui': '#d3ebe9', 'cterm':194 }

red = { 'gui': 'red', 'cterm':196 } ##c23127
orange = { 'gui': 'orange', 'cterm':166 } ##d26937
yellow = { 'gui': 'yellow', 'cterm':226 } ##edb443
magenta = { 'gui': 'magenta', 'cterm':67 } #888ca6
violet = { 'gui': 'violet', 'cterm':60 } #4e5166
blue = { 'gui': 'blue', 'cterm':24 } #195466
cyan = { 'gui': 'cyan', 'cterm':44 } #33859E
green = { 'gui': 'lightgreen', 'cterm':46 } #2aa889
white = { 'gui': 'white', 'cterm':46 } #2aa889

termColor8 = termColor0 = base0.get('gui')
termColor9 = termColor1 = red.get('gui')
termColor10 = termColor2 = green.get('gui')
termColor11 = termColor3 = yellow.get('gui')
termColor12 = termColor4 = blue.get('gui')
termColor13 = termColor5 = violet.get('gui')
termColor14 = termColor6 = cyan.get('gui')
termColor15 = termColor7 = base6.get('gui')

bckGrnd = base0
lnrBckgrnd = base1

def hiSET(hiTerm, ctermfg, ctermbg, isBold=None):
  #print(ctermfg, ctermbg)
  if ctermbg:
    ctrmbg=ctermbg.get('cterm', None)
    guibg=ctermbg.get('gui', None)
  if ctermfg:
    ctrmfg=ctermfg.get('cterm', None)
    guifg=ctermfg.get('gui', None)
 
  #CMD=f'exec "hi clear {hiTerm}|hi {hiTerm} ctermfg={ctermfg} ctermbg={ctermbg} guifg={ctermfg} guibg={ctermbg} gui=NONE cterm=NONE"'
  if hiTerm.find('Tab')!=-1:
    boldTerm='cterm=bold'
    CMD=f'exec "hi clear {hiTerm}|hi! {hiTerm} guifg={guifg} guibg={guibg}"' #ctermfg={ctermfg} ctermbg={ctermbg} {boldTerm}
  else:
    CMD=f'exec "hi clear {hiTerm}|hi! {hiTerm} guifg={guifg} guibg={guibg}"' #ctermfg={ctermfg} ctermbg={ctermbg} 
    #print('CMD=', CMD)
  vim.command(CMD)

#hiSET('Normal', yellow, bckGrnd)
#hiSET('Cursor', yellow, base6)
#hiSET('CurSearch', red, base6)
#hiSET('CursorLine', None, None)
#hiSET('CursorColumn', None, base1)
#hiSET('LineNr', yellow, lnrBckgrnd)
#hiSET('CursorLineNr', base5, lnrBckgrnd)
#hiSET('SignColumn', None, lnrBckgrnd)
#hiSET('ColorColumn', None, lnrBckgrnd)
#hiSET('Conceal', cyan, bckGrnd)
#hiSET('Todo', magenta, bckGrnd)

#hiSET('Comment', blue, None)
#hiSET('String', green, None)
#hiSET('Number', orange, None)
#hiSET('Statement', base5, None)
#hiSET('Special', orange, None)
#hiSET('Identifier', base5, None)
#hiSET('Constant', magenta, None)

#hiSET('VertSplit', red, lnrBckgrnd)
#hiSET('StatusLine', base5, base2)
#hiSET('WildMenu', base7, cyan)
#hiSET('StatusLineNC', blue, base2)
#hiSET('ErrorMsg', cyan, base1)
#hiSET('Error', red, base1)
#hiSET('ModeMsg', blue, None)
#hiSET('WarningMsg', red, None)

#hiSET('TabLineSel', yellow, bckGrnd)
#hiSET('TabLine', red, bckGrnd)
#hiSET('TabLineFill', green, bckGrnd)
#hiSET('Title', orange, yellow)

#hiSET('Visual', yellow, red)
#hiSET('Search', orange, yellow)
#hiSET('MatchParen', base6, orange)
#call s:Attr('IncSearch', 'reverse')
#hiSET('Pmenu', base6, base2)
#hiSET('PmenuSel', base7, blue)
#hiSET('PmenuSbar', None, base2)
#hiSET('PmenuThumb', None, blue)
#hiSET('CtrlPNoEntries', base7, orange)
#hiSET('CtrlPMatch', green, orange)
#hiSET('CtrlPPrtBase', blue, orange)
#hiSET('CtrlPPrtText', cyan, orange)
#hiSET('CtrlPPtrCursor', base7, orange)
#hiSET('pythonStatement', blue, orange)

vim.command(':com! -nargs=* SetHiColor py3 hiSET(<f-args>)')
vim.api.set_keymap('n', '<leader>his', '<cmd>SetHiColor<CR>', {'noremap':True, 'silent':False})
" Color: xterm0 #000000 16 black
" Color: xterm1 #cd0000 160 darkred
" Color: xterm2 #00cd00 40 darkgreen
" Color: xterm3 #cdcd00 184 darkyellow
" Color: xterm4 #0000ee 20 darkblue
" Color: xterm5 #cd00cd 164 darkmagenta
" Color: xterm6 #00cdcd 44 darkcyan
" Color: xterm7 #e5e5e5 254 grey
" Color: xterm8 #7f7f7f 102 darkgrey
" Color: xterm9 #ff0000 196 red
" Color: xterm10 #00ff00 46 green
" Color: xterm11 #ffff00 226 yellow
" Color: xterm12 #5c5cff 63 blue
" Color: xterm13 #ff00ff 201 magenta
" Color: xterm14 #00ffff 51 cyan
" Color: xterm15 #ffffff 231 white
" Color: Pmenu #444444 238 darkgrey
" Color: rgbGrey40 #666666 59 darkgrey
" Color: rgbDarkGrey #a9a9a9 145 grey
" Color: rgbDarkBlue #00008b 20 darkblue
" Color: rgbDarkMagenta #8b008b 90 darkmagenta
" Color: rgbBlue #0000ff 21 darkblue
" Color: rgbDarkCyan #008b8b 44 darkcyan
" Color: rgbSeaGreen #2e8b57 29 darkgreen
" Color: rgbGrey #bebebe 250 grey
" Color: StatusLineTerm #90ee90 120 darkgreen
" Color: ToolbarLine #7f7f7f 244 darkgrey
" Color: Comment #80a0ff 111 blue
" Color: Constant #ffa0a0 217 darkred
" Color: Special #ffa500 214 darkyellow
" Color: Identifier #40ffff 87 cyan
" Color: Statement #ffff60 227 yellow
" Color: PreProc #ff80ff 213 magenta
" Color: Type #60ff60 83 green
" Color: koeDirectory #cc8000 172 darkyellow
" Color: koeCursorLine #555555 240 black
" Color: koeLightBlue #ADD8E6 153 blue
" Color: koeDarkRed #8b0000 88 darkred
" Term colors: xterm0 xterm1 xterm2 xterm3 xterm4 xterm5 xterm6 xterm7
" Term colors: xterm8 xterm9 xterm10 xterm11 xterm12 xterm13
" Term colors: xterm14 xterm15
" Color: bgDiffA #5F875F 65 darkgreen
" Color: bgDiffC #5F87AF 67 blue
" Color: bgDiffD #AF5FAF 133 magenta
" Color: bgDiffT #C6C6C6 251 grey
" Color: fgDiffW #FFFFFF 231 white
" Color: fgDiffB #000000 16 black
" Color: bgDiffC8 #5F87AF 67 darkblue
" Color: bgDiffD8 #AF5FAF 133 darkmagenta
'''
