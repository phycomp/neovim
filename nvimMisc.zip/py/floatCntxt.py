def floatCntxt(fname):
    import sys
    absPath=vim.funcs.expand('%:p:h')
    cntxt=vim.funcs.readfile('/'.join([absPath, fname]))
    sys.path.append(absPath)
    #print('pythonPATH=', sys.path)
    #cntxt=cntxt.replace('\n', '')
    #print(cntxt)
    from regMark import bufWin
    bufWin(cntxt)
vim.command(':com! -nargs=* CntxtFloat py3 floatCntxt(<f-args>)')
vim.api.set_keymap('n', '<leader>cfl', ':CntxtFloat ', {'noremap':True, 'silent':False})
