#vim.api.set_keymap('n', '<leader>mrg', ':MrgCMD ', {'noremap':True, 'silent':False})    #:mksession! ~/.config/nvim/last.sssn
vim.api.set_keymap('n', '<leader>mls', '<cmd>MergeCMD mks latest.sssn<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>sls', '<cmd>MergeCMD source latest.sssn<CR>', {'noremap':True, 'silent':False})
"""
#:com -nargs=* MkSSN call MkSSN(<f-args>)

def MkSSN(ssn):
    import vim
    vim.command(f':mksession! ~/.config/nvim/{ssn}.sssn')
"""

