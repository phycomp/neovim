'''
    {"ms-jpq/chadtree", branch='char', run=function()vim.cmd[[python3 -m chadtree deps]]end},
    'nvim-tree/nvim-tree.lua';
    Plug 'ms-jpq/chadtree', {'branch': 'chad', 'do': ''}

'''
vim.api.set_keymap('n', '<leader>chd', "<cmd>CHADopen<CR>", {'noremap':True, 'silent':False})
