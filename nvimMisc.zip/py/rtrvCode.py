import vim
def getFirstChan():
    termChans = []
    for chan in vim.api.list_chans():
      if chan["mode"] == "terminal" and chan["pty"]: termChans.append(chan)
    chan=termChans[0]#['id']
    return chan#vim.funcs.bufnr(buf)
    #print('termChans=', termChans)
    #table.sort(
    #for k, v in termChans.items():
    #    lambda left, right: left['buffer'] if left["buffer"] < right["buffer"] else right['buffer']
    #print(termChans)
    #return termChans[1]["id"]

def rtrvRunCode():
    getpos=vim.funcs.getpos
    #eval=vim.eval
    execMode=vim.funcs.mode()
    print('mode=', execMode)
    startPos, endPos=getpos("'<"), getpos("'>")#+2
    startLine=startPos[1]
    endLine=endPos[1]
    buf=vim.current.buffer
    cmdCode=buf[startLine-1:endLine]
    #print(startLine, endLine, buf, cmdCode)
    return cmdCode
#print(startPos, endPos)
#content = vim.api.buf_get_lines(0, 0, vim.api.buf_line_count(0), False)
#content=vim.api.buf_get_lines(0, 0, -1, False)
#print(content)
#def showFile(): return 'ls'
#def nullFunc(): pass
def fullBuf():
    buf=vim.current.buffer
    return buf[:]
def rtrvCode():
    cmdCode=rtrvRunCode()
def showPic(ext='png'):
    from subprocess import Popen, PIPE
    from os.path import split
    #PICs=' '.join(PICs)
    #PICs=PICs.communicate()[0].decode('utf-8')#.strip('\n')
    cmd='ls /home/josh/*.png'
    CMD=split(cmd)
    #PICs=Popen(CMD, stdout=PIPE, stderr=PIPE, stdin=PIPE)
    #output=Popen(CMD, stdout=PIPE, stderr=PIPE)  #, shell=True)
    #PICs=output.stdout.read()#.replace('\n', chr(10))
    #print('PICs=', PICs)
    PICs=['streamlitHowto2.png', 'streamlitHowto.png']
    PICs=' '.join(PICs)
    cmdCode=f'''termvisage {PICs}'''
    #print('cmdCode=', cmdCode)
    return cmdCode
def commitCode(cmdCode):
    #vim.funcs.nvim_get_chan_info()
    #chanID = vim.funcs.chan_open('localhost:6000', {'callback':'rtrvRunCode'})
    if type(cmdCode)==str: CMDs='\n'.join([cmdCode])
    #vim.api.command(cmd)
    elif type(cmdCode)==list: CMDs='\n'.join(cmdCode)
    #vim.command(':b 53')
    #CMDs=f''':term! python -c "{CMDs}"'''
    #pythonPrefix=['python -c']
    #pythonPrefix.extend(cmdCode)
    CMDs=f'''{CMDs}\r'''
    #print('CMDs=', CMDs)
    #vim.funcs.feedkeys(3, CMDs)
    #print('pythonPrefix=', pythonPrefix)
    chan=getFirstChan()
    vim.funcs.chansend(chan['id'], CMDs)
    #await vim.funcs.chansend(chan['id'], '\r')
    #buf=chan['buffer']
    #vim.funcs.feedkeys(vim.funcs.bufnr(buf), '\r')
    #print('CMDs=', CMDs)
    #termCode=vim.funcs.termopen(CMDs)
    #print('CMDs=', CMDs, termCode)
    #print('extend=', pythonPrefix)
    #vim.funcs.jobstart(pythonPrefix)
    #vim.api.open_term(6, {'on_input':showFile})
    #vim.funcs.jobstart([CMDs], {})  #'rpc':True
    #vim.command(CMDs)
    #vim.call('jobstart', [CMDs], {'on_stdout':nullFunc})
    #vim.command(f'''
    #:call jobstart('{CMDs}', {'on_stdout':{j,d,e->append(line('.'),d)}})
    #            ''')
