def merge(*args):   #mode, fname, ext
  from os.path import splitext
  mode, fname=args
  base, ext=splitext(fname)
  #if mode in ['source', 'pyfile']:
  DIR=ext[1:]
  if any(mode in x for x in ['source', 'pyfile'])==True:
    CMD=f'{mode} ~/.config/nvim/{DIR}/{fname}'
  else:
    CMD=f'{mode}! ~/.config/nvim/{DIR}/{fname}'
  vim.command(CMD)
#vim.api.set_keymap('n', 'MergeCMD', 'py3 merge(<f-args>)')
vim.command(':com! -complete=file -nargs=* MergeCMD py3 merge(<f-args>)')
#:command -nargs=+ -complete=command Allargs call Allargs(<q-args>)
#:com -nargs=* Mycmd call Myfunc(<f-args>)
vim.api.set_keymap('n', '<leader>mc', ':MergeCMD ', {'noremap':True, 'silent':False})
"""
def mrgCMD(*args):
    #fname=vim.funcs.expand('%')
    cmdType, fname=args
    cmd=f'MergeCMD {cmdType} {fname}'
    print(cmd)
    vim.command(cmd)
"""

