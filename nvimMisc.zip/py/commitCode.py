#import 
import rtrvCode
import imp
imp.reload(rtrvCode)
'''
python<<EOF
bufCmd=rtrvCode.fullBuf()
rtrvCode.commitCode(bufCmd)
EOF
'''
vim.api.set_keymap('n', '<leader>pbr', '<cmd>py3 bufCmd=rtrvCode.fullBuf();rtrvCode.commitCode(bufCmd)<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('v', '<leader>pvr', '<cmd>py3 visCmd=rtrvCode.rtrvRunCode();rtrvCode.commitCode(visCmd)<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('v', '<leader>pvr', '<cmd>py3 visCmd=rtrvCode.rtrvRunCode();rtrvCode.commitCode(visCmd)<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>pir', '<cmd>py3 visCmd=rtrvCode.showPic();print("visCmd=", visCmd);rtrvCode.commitCode(visCmd)<CR>', {'noremap':True, 'silent':False})
