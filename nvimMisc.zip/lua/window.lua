vim.g.tiddlywiki_author = "Ori"
local fTypes={'help', 'vim', 'netrw', 'nvimtree'}
indexOf=function(array, value)
    for i, v in ipairs(array) do
        if v == value then
            return i
        end
    end
    return nil
end

vim.g.isFtyped=indexOf(fTypes, vim.b.filetype)~= -1 --vim.api.index()
LeftWin=function()
  if vim.api.winnr()==1 then
    return
  end
  if vim.g.isFtyped then
    local prvPos=vim.api.getpos("'\"")
    --vim.api.mark(m)
    vim.api.nvim_buf_set_mark('m')
  end
  local curBufID=vim.api.bufnr()
  vim.api.wincmd('h')
  local prvBufID=vim.api.bufnr()
  vim.cmd[[ exec ':buffer!'. curBufID ]]
  vim.api.wincmd('l')
  vim.cmd[[ exec ':buffer!'. prvBufID ]]
  vim.api.wincmd('h')
  if vim.g.isFtyped then
    --vim.cmd[["'m]]
    vim.api.nvim_buf_get_mark('m')
    vim.api.setpos(".", prvPos)
  end
end

RightWin=function()
  if vim.api.winnr()==vim.api.winnr('$') then
    return
  end
  if vim.g.isFtyped then
    local prvPos=vim.api.getpos("'\"")
    vim.api.nvim_buf_set_mark('m')
    --"normal! mark m
  end
  local curBufID=vim.api.bufnr()
  vim.api.wincmd('l')
  local prvBufID=vim.api.bufnr()
  vim.cmd[[ exec ':buffer!'. curBufID ]]
  vim.api.wincmd('h')
  vim.cmd[[ exec ':buffer!'. prvBufID ]]
  vim.api.wincmd('l')
  if vim.g.isFtyped then
    vim.api.nvim_buf_get_mark('m')
    vim.api.setpos(".", prvPos)
  end
end

vim.api.nvim_set_keymap('n', '<leader>wh', '<cmd>call LeftWin()<CR>', {silent=false, noremap=true})
vim.api.nvim_set_keymap('n', '<leader>wl', '<cmd>call RightWin()<CR>', {silent=false, noremap=true})
vim.api.nvim_set_keymap('n', '<leader>vn', '<cmd>vnew<CR>', {silent=false, noremap=true})
vim.api.nvim_set_keymap('n', '<M-Right>', '<cmd>wincmd l<CR>', {silent=false, noremap=true})
vim.api.nvim_set_keymap('n', '<M-Left>', '<cmd>wincmd h<CR>', {silent=false, noremap=true})
