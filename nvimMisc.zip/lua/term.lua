highlight Cursor guifg=NONE guibg=Green
highlight lCursor guifg=NONE guibg=Cyan
