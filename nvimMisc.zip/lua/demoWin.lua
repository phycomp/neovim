local open_floating_win = function()
  vim.api.nvim_open_win(
    vim.api.nvim_create_buf(true, false),
    false,
    { relative = 'editor', row = 0, col = 0, width = 20, height = 10 }
  )
end

vim.keymap.set('n', '<Space>o', open_floating_win)
