local vimCMD = vim.cmd

vimCMD('let g:UltiSnipsExpandTrigger="<tab>"')
vimCMD('let g:UltiSnipsListSnippets="<c-tab>"')
vimCMD('let g:UltiSnipsJumpForwardTrigger="<c-j>"')
vimCMD('let g:UltiSnipsJumpBackwardTrigger="<c-k>"')
vimCMD('let g:UltiSnipsSnippetDirectories = [ "UltiSnips" ]')
vimCMD('set mouse=a')

vim.g.python3_host_prog = vim.env.VIRTUAL_ENV.."/bin/python"
--vimCMD(a)
--vimCMD('source /home/josh/.vim/startup/window.vim')
--vimCMD('source /home/josh/.vim/startup/cmdline.vim')
--vimCMD('source /home/josh/.vim/startup/web.vim')
--vimCMD('source /home/josh/.vim/startup/buffer.vim')
--vimCMD('source /home/josh/.vim/startup/visual.vim')
--vimCMD('source /home/josh/.vim/startup/b2g.vim')
--vimCMD('source /home/josh/.vim/startup/keys.vim')
--vimCMD('source /home/josh/.vim/startup/RinseBuf.vim')
--vimCMD('source /home/josh/.vim/startup/filetype.vim')
--vimCMD('source /home/josh/.vim/startup/session.vim')
--vimCMD('source /home/josh/.vim/startup/settings.vim')
--vimCMD('source /home/josh/.vim/startup/window.vim')
--vimCMD('source /home/josh/.vim/startup/status.vim')
--vimCMD('source /home/josh/.vim/startup/help.vim')
--vimCMD('source /home/josh/.vim/startup/guifont.vim')
--vimCMD('source /home/josh/.vim/startup/ridPttrn.vim')
--vim.cmd('source /home/josh/.vim/startup/nvim-tree.nvim')
--vim.cmd('source /home/josh/.vim/startup/python.vim')
--vim.cmd('source /home/josh/.vim/startup/delimitMate.vim')
--vim.cmd('source /home/josh/.vim/startup/emmet.vim')
--vim.cmd('source /home/josh/.vim/startup/tab.vim')
--vim.cmd('source /home/josh/.vim/startup/rainbow.vim')
--vim.cmd('source /home/josh/.vim/startup/jupyter.vim')
--vim.cmd('source /home/josh/.vim/startup/whichkey.vim')
require'settings'
require'status'
require'ftype'
--require'keys'
require'keys'
require'window'
require'buffer'
require'b2g'
--require'ftyp'
require'paqs'
require'ridPttrn'
require'cmdline'
--require'compeSettings'
require'utils'
--require'plugins'
--require'term'
--vim.cmd[[luafile
