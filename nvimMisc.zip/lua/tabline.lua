local theme = {
  --fill = 'TabLineFill',
  -- Also you can do this: #E7331A  #F16A16, , #FFC82F, #F6FF92, #0D98BA and #0074A5.
  fill={fg='#907aa9', bg='#f2e9de', style='italic'},
  head = 'TabLine', current_tab = 'TabLineSel', tab = 'TabLine', win = 'TabLine', tail = 'TabLine',
}
local rtrvFname=function(fname)
  --local fileName=fname:match("^(.+)%.?.+$")
  local fName=fname:find('%.') and fname:match("^(.+)%..+$") or fname
  if #fName>9 then
    return fName:sub(1, 9)
  else
    return fName
  end
  --return fName:sub(1, 5) and (#fName > 10) or fName
  --if fname:find('%.') then
  --  return fname:match("^(.+)%..+$")
  --else
  --  return fname
  --end
end

require('tabby.tabline').set(function(line)
  return {
    {
      { '  ', hl = theme.head },
      line.sep('', theme.head, theme.fill),
    },
    line.tabs().foreach(function(tab)
      --print('tabName=', tab.name())
      local hl = tab.is_current() and theme.current_tab or theme.tab
      --local tabName=tab.name()
      --tabName= tabName:find('%.') and tabName:match("(.+)%..+") or tabName
      return {
        line.sep('', hl, theme.fill),
        tab.is_current() and '' or '󰆣',
        rtrvFname(tab.name()),
        --tabName,
        tab.close_btn(''),
        line.sep('', hl, theme.fill),
        hl = hl,
        margin = ' ',
      }
    end),
    line.spacer(),
    line.wins_in_tab(line.api.get_current_tab()).foreach(function(win)
      local winName=win.buf_name()
      --winName=winName:find('%.') and winName:match("^(.+)%.?.*$") or winName
      --local winName=win.buf_name():gmatch"(.-)@FILENAMEMARKER#(.-)\r?\n"
      --if not winName then winName='None' end  --win.buf_name()
      return {
        line.sep('', theme.win, theme.fill),
        win.is_current() and '' or '',
        --winName,
        rtrvFname(win.buf_name()),
        line.sep('', theme.win, theme.fill),
        hl = theme.win,
        margin = ' ',
      }
    end),
    {
      line.sep('', theme.tail, theme.fill),
      { '  ', hl = theme.tail },
    },
    hl = theme.fill,
  }
end)
