vim.g.neovide_input_use_logo = 1
vim.g.neovide_padding_top = 0
vim.g.neovide_padding_bottom = 0
vim.g.neovide_padding_right = 0
vim.g.neovide_padding_left = 0
vim.g.neovide_position_animation_length = 0
vim.g.neovide_cursor_animation_length = 0.00
vim.g.neovide_cursor_trail_size = 0
vim.g.neovide_cursor_animate_in_insert_mode = false
vim.g.neovide_cursor_animate_command_line = false
vim.g.neovide_scroll_animation_far_lines = 0
vim.g.neovide_scroll_animation_length = 0.00
vim.g.neovide_remember_window_size = true
--vim.o.guifont = "Courier New:Source Code Pro:h24" -- text below applies for VimScript
--vim.o.guifont="Source Code Pro:h24:#h-slight"
-- Allow clipboard copy paste in neovim
--vim.api.nvim_set_keymap('', '<D-v>', '+p<CR>', { noremap = true, silent = true})
--vim.api.nvim_set_keymap('!', '<D-v>', '<C-R>+', { noremap = true, silent = true})
vim.g.neovide_profiler = false
vim.g.neovide_remember_window_size = true
vim.g.neovide_fullscreen = false
--vim.api.nvim_set_keymap('t', '<D-v>', '<C-R>+', { noremap = true, silent = true})
